
Ext.define('rdec.Application', {
    extend: 'Ext.app.Application',
    
    name: 'rdec',

    stores: [
        // TODO: add global / shared stores here
    ],
    
    launch: function () {
        // TODO - Launch the application
    },
	controllers : 
		[],
});
