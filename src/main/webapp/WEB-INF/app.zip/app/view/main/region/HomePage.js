/**
 * 
 * 系统首页的字义
 * 
 */

Ext.define('rdec.view.main.region.HomePage', {
	
	extend : 'Ext.panel.Panel',
	
	alias : 'widget.homepage',
	
	layout : 'border',

	items : [{
		region : 'center'
	}]

})